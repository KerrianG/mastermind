package org.iut.mastermind.domain.tirage;

public interface ServiceNombreAleatoire {
    int next(int borneSup);
}
