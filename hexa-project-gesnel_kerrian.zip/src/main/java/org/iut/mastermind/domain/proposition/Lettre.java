package org.iut.mastermind.domain.proposition;

public enum Lettre {
    PLACEE,         // lettre bien placée
    NON_PLACEE,     // lettre dans le mot mais mal placée
    INCORRECTE      // lettre absente du mot
}
